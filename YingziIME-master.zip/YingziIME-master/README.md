# 影子输入法

我来说几句，这个输入法是我目前的主力输入法。暂时就是这个样子。

#### 介绍
影子输入法是由“河许人”发起，“天黑请闭眼”深度开发的简单、简洁、高度自定义的输入法。取名“影子”，意在效率上发力，让你有不一样的输入，让你指间生花，让你的操作像一片“影子”！

#### 精简版(不包含词库)
未注册gitee用户可以在点击下载[Yzime.7z(源码包)](https://gitee.com/orz707/Yzime/raw/zip/Yzime.7z)文件解压，和[Yzime.exe](https://gitee.com/orz707/Yzime/raw/zip/Yzime.exe)到Yzime.ahk文件所在目录，运行Yzime.exe使用。  

下载后需额外下载[初始词库](https://wwi.lanzoui.com/id81bpi)到Yzime.exe所在目录后，再运行Yzime.exe自动释放初始词库。

**存在Data\ciku.db，不会释放初始词库**

#### [完整包下载](https://wwi.lanzoui.com/iQaDAsojgob)(解压即用)

#### v2.0.0
**2.0版本加入TSF模块，开启后，在输入法切换栏中加入Yzime选项(可能需要手动在“系统设置-语言首选项”里添加键盘)，和其他安装版输入法一样切换，可以在外挂式输入法不能使用的应用中正常输入。使用C++重做词库管理，告别未响应，使用更顺滑。**

**本版本没有其他网站和QQ群**

更多内容详见[帮助文档](https://gitee.com/orz707/Yzime/wikis/%E5%BF%AB%E9%80%9F%E5%BC%80%E5%A7%8B?sort_id=1844118)

[更新日志](https://gitee.com/orz707/Yzime/wikis/%E6%9B%B4%E6%96%B0%E6%97%A5%E5%BF%97?sort_id=1811043)

[蓝奏网盘](https://wwi.lanzoui.com/b01bga84b)  